# 2playerTicTacToe
Tic Tac Toe Game for 2 player using OpenGl
